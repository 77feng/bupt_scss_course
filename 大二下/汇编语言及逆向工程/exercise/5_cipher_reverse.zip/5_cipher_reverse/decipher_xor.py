# -*- coding: utf-8 -*-

token = b'\x06\x07\x08\x09\x0A\x0B\x0C\x0D'            #'abcdefg123'
ciphertext = b'\x52\xC7\xC2\xCD\xEE\xEB\xFE\xF5'

#result = ''.join(chr(ord(token[i]) ^ ciphertext[i]) for i in range(10))
result = ''.join( chr(token[i] ^ ciphertext[i]) for i in range(10))

print("result is: %s\n" %(result))
