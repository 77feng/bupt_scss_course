#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <time.h>
#include <limits.h>
#include <string.h>
#include <stdint.h>
#include <wchar.h>
#include <windows.h>
#include <wincrypt.h>

/* Link with the Advapi32.lib file for Crypt* functions */
#pragma comment (lib, "Advapi32")

int globalReturnsTrue()
{
    return 1;
}

int globalReturnsFalse()
{
    return 0;
}

void printLine (const char * line)
{
    if(line != NULL)
    {
        printf("%s\n", line);
    }
}


void function()
{
    if (globalReturnsTrue())
    {
        FILE *pFile;
        HCRYPTPROV hCryptProv;
        HCRYPTKEY hKey;
        HCRYPTHASH hHash;
        char password[100];
        size_t passwordLen;
        // ����ʹ�ù̶����ȵĻ��������洢����������
        char *toBeDecrypted = NULL;
        DWORD toBeDecryptedLen = 0;

        printLine("Enter the password: ");
        if (fgets(password, 100, stdin) == NULL)
        {
            printLine("fgets() failed");
            password[0] = '\0';
        }
        passwordLen = strlen(password);
        if (passwordLen > 0)
        {
            password[passwordLen - 1] = '\0';

            // ʹ�����밲ȫ�Ĺ�ϣ�㷨������������
            // ����ֻ��ʾ����ʵ��Ӧ������Ҫ��ȷ���ɺ�ʹ�������ϣ��
            // ���辭�������ϣ�⴦����������ϣ�洢�� passwordHash ��
            // char passwordHash[HASH_LENGTH];
            // hashPassword(password, passwordHash);
        }

        pFile = fopen("encrypted.txt", "rb");
        if (pFile == NULL)
        {
            exit(1);
        }

        // ��ȡ�ļ���С
        fseek(pFile, 0, SEEK_END);
        long fileSize = ftell(pFile);
        fseek(pFile, 0, SEEK_SET);

        // �����ļ���С�����ڴ�
        toBeDecrypted = (char *)malloc(fileSize + 1);
        if (toBeDecrypted == NULL)
        {
            fclose(pFile);
            exit(1);
        }

        // ��ȡ�ļ�����
        if (fread(toBeDecrypted, sizeof(char), fileSize, pFile)!= fileSize)
        {
            free(toBeDecrypted);
            fclose(pFile);
            exit(1);
        }
        toBeDecrypted[fileSize] = '\0';
        toBeDecryptedLen = fileSize;

        if (!CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, 0))
        {
            if (!CryptAcquireContext(&hCryptProv, NULL, MS_ENH_RSA_AES_PROV, PROV_RSA_AES, CRYPT_NEWKEYSET))
            {
                printLine("Error in acquiring cryptographic context");
                free(toBeDecrypted);
                exit(1);
            }
        }

        if (!CryptCreateHash(hCryptProv, CALG_SHA_256, 0, 0, &hHash))
        {
            printLine("Error in creating hash");
            free(toBeDecrypted);
            exit(1);
        }

        if (!CryptHashData(hHash, (BYTE *)password, passwordLen, 0))
        {
            printLine("Error in hashing password");
            free(toBeDecrypted);
            exit(1);
        }

        if (!CryptDeriveKey(hCryptProv, CALG_DES, hHash, 0, &hKey))
        {
            printLine("Error in CryptDeriveKey");
            free(toBeDecrypted);
            exit(1);
        }

        if (!CryptDecrypt(hKey, 0, 1, 0, (BYTE *)toBeDecrypted, &toBeDecryptedLen))
        {
            printLine("Error in decryption");
            free(toBeDecrypted);
            exit(1);
        }

        printLine(toBeDecrypted);

        if (hKey)
        {
            CryptDestroyKey(hKey);
        }
        if (hHash)
        {
            CryptDestroyHash(hHash);
        }
        if (hCryptProv)
        {
            CryptReleaseContext(hCryptProv, 0);
        }
        if (pFile)
        {
            fclose(pFile);
        }

        // �ͷŷ�����ڴ�
        free(toBeDecrypted);
    }
}


int main(int argc, char * argv[])
{
    /* seed randomness */
    srand( (unsigned)time(NULL) );

    printLine("doubao...");
    function();

    return 0;
}

